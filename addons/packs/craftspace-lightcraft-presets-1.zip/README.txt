Sixteen LightCraft develop presets in four groups (Portrait, Landscape, Street, B&W).

In LightCraft: File > Import Profiles & Presets..., then choose CraftSpace Presets.lcpreset.
