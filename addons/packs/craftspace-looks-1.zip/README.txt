CraftSpace Looks: twelve 33-point 3D LUTs (.cube).

- LightCraft: File > Import Profiles & Presets..., choose the CraftSpace Looks folder.
  They appear as creative profiles.
- FilmCraft: Lumetri Color > Creative > Look > Browse...
- EffectCraft: Effect > Utility > Apply Color LUT.
- PhotoCraft: Image > Adjustments > Color Lookup..., choose a 3D LUT file.
