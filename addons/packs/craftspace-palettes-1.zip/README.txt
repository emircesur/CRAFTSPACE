CraftSpace Palettes: seven palettes in three formats.

- GIMP palettes (.gpl): VectorCraft lists them under Swatches > User Defined.
- Adobe swatch exchange (.ase): PhotoCraft, DesignCraft and VectorCraft.
- Photoshop swatches (.aco): PhotoCraft.
